import { AuthGuard } from './auth.guard';

export const guards = [AuthGuard];

export * from './auth.guard';
