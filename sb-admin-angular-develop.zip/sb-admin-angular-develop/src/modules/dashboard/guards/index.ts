import { DashboardGuard } from './dashboard.guard';

export const guards = [DashboardGuard];

export * from './dashboard.guard';
